import { NativeModules, NativeEventEmitter, EmitterSubscription } from "react-native";
import { PerkoxInitConfig, PerkoxOfferwallOptions, PerkoxReward } from "./types";

const { PerkoxModule } = NativeModules;

let perkoxEmitter: NativeEventEmitter | null = null;

function getEventEmitter(): NativeEventEmitter | null {
  if (!perkoxEmitter && NativeModules.PerkoxModule) {
    try {
      perkoxEmitter = new NativeEventEmitter(NativeModules.PerkoxModule);
    } catch (e) {
      console.warn("[Perkox SDK] Failed to initialize NativeEventEmitter:", e);
    }
  }
  return perkoxEmitter;
}

export class PerkoxSDK {
  private static appId: string = "";
  private static sdkKey: string = "";
  private static playerId: string = "";
  private static beta: boolean = false;
  private static isInitialized: boolean = false;

  private static rewardListeners: Set<(reward: PerkoxReward) => void> = new Set();
  private static closeListeners: Set<() => void> = new Set();

  private static rewardSubscription: EmitterSubscription | null = null;
  private static closeSubscription: EmitterSubscription | null = null;

  /**
   * 1. INIT: Initializes the Perkox React Native SDK.
   * Native SDK Bridge call + JS configuration.
   */
  public static async init(config: PerkoxInitConfig): Promise<boolean>;
  public static async init(appId: string, sdkKey: string, playerId?: string, beta?: boolean): Promise<boolean>;
  public static async init(
    configOrAppId: PerkoxInitConfig | string,
    sdkKey?: string,
    playerId?: string,
    beta: boolean = false
  ): Promise<boolean> {
    if (typeof configOrAppId === "object") {
      PerkoxSDK.appId = configOrAppId.appId || "";
      PerkoxSDK.sdkKey = configOrAppId.sdkKey || "";
      PerkoxSDK.playerId = configOrAppId.playerId || "";
      PerkoxSDK.beta = configOrAppId.beta ?? false;
    } else {
      PerkoxSDK.appId = configOrAppId || "";
      PerkoxSDK.sdkKey = sdkKey || "";
      PerkoxSDK.playerId = playerId || "";
      PerkoxSDK.beta = beta ?? false;
    }

    PerkoxSDK.setupNativeEventListeners();
    PerkoxSDK.isInitialized = true;

    if (NativeModules.PerkoxModule && typeof NativeModules.PerkoxModule.initSDK === "function") {
      try {
        await NativeModules.PerkoxModule.initSDK(PerkoxSDK.appId, PerkoxSDK.sdkKey, {
          playerId: PerkoxSDK.playerId,
          beta: PerkoxSDK.beta,
        });
      } catch (err) {
        console.warn("[Perkox SDK] Native initSDK warning:", err);
      }
    }

    return true;
  }

  /**
   * 2. LOGIN / SET USER: Sets or updates the unique Player ID / User ID.
   */
  public static async setUserId(playerId: string): Promise<boolean> {
    PerkoxSDK.playerId = playerId || "";

    if (NativeModules.PerkoxModule && typeof NativeModules.PerkoxModule.setUserId === "function") {
      try {
        await NativeModules.PerkoxModule.setUserId(PerkoxSDK.playerId);
      } catch (err) {
        console.warn("[Perkox SDK] Native setUserId warning:", err);
      }
    }

    return true;
  }

  /**
   * 3. SHOW OFFERWALL: Triggers the Native Offerwall display using the native Android/iOS SDK bridge.
   */
  public static async showOfferwall(options?: PerkoxOfferwallOptions): Promise<boolean> {
    const appId = options?.appId ?? PerkoxSDK.appId ?? "";
    const sdkKey = options?.sdkKey ?? PerkoxSDK.sdkKey ?? "";
    const playerId = options?.playerId ?? PerkoxSDK.playerId ?? "";
    const beta = options?.beta ?? PerkoxSDK.beta ?? false;

    if (!appId || !sdkKey) {
      console.error("[Perkox SDK] Error: appId and sdkKey are required before showing offerwall.");
      return false;
    }

    if (!playerId) {
      console.warn("[Perkox SDK] Warning: playerId is empty. Make sure user is logged in or playerId is set.");
    }

    if (!NativeModules.PerkoxModule) {
      console.warn(
        "[Perkox SDK] Native module 'PerkoxModule' is not linked. Please ensure native modules are installed."
      );
      return false;
    }

    PerkoxSDK.setupNativeEventListeners();

    try {
      return await NativeModules.PerkoxModule.showOfferwall(appId, sdkKey, playerId, beta);
    } catch (err) {
      console.error("[Perkox SDK] Failed to show offerwall:", err);
      return false;
    }
  }

  /**
   * 4. EVENTS: Subscribe to reward events.
   */
  public static onReward(callback: (reward: PerkoxReward) => void): () => void {
    PerkoxSDK.rewardListeners.add(callback);
    PerkoxSDK.setupNativeEventListeners();

    return () => {
      PerkoxSDK.rewardListeners.delete(callback);
    };
  }

  /**
   * 4. EVENTS: Subscribe to offerwall close events.
   */
  public static onClose(callback: () => void): () => void {
    PerkoxSDK.closeListeners.add(callback);
    PerkoxSDK.setupNativeEventListeners();

    return () => {
      PerkoxSDK.closeListeners.delete(callback);
    };
  }

  /**
   * 5. CONFIG: Update SDK Configuration parameters.
   */
  public static setConfig(config: Partial<PerkoxInitConfig>): void {
    if (config.appId !== undefined) PerkoxSDK.appId = config.appId || "";
    if (config.sdkKey !== undefined) PerkoxSDK.sdkKey = config.sdkKey || "";
    if (config.playerId !== undefined) PerkoxSDK.setUserId(config.playerId || "");
    if (config.beta !== undefined) PerkoxSDK.beta = config.beta;
  }

  /**
   * Getters for current SDK config
   */
  public static getAppId(): string {
    return PerkoxSDK.appId;
  }

  public static getSdkKey(): string {
    return PerkoxSDK.sdkKey;
  }

  public static getPlayerId(): string {
    return PerkoxSDK.playerId;
  }

  public static isBeta(): boolean {
    return PerkoxSDK.beta;
  }

  private static setupNativeEventListeners() {
    const emitter = getEventEmitter();
    if (!emitter) return;

    if (!PerkoxSDK.rewardSubscription) {
      PerkoxSDK.rewardSubscription = emitter.addListener("onPerkoxReward", (reward: PerkoxReward) => {
        PerkoxSDK.rewardListeners.forEach((listener) => {
          try {
            listener(reward);
          } catch (e) {
            console.error("[Perkox SDK] Exception in onReward listener:", e);
          }
        });
      });
    }

    if (!PerkoxSDK.closeSubscription) {
      PerkoxSDK.closeSubscription = emitter.addListener("onPerkoxClose", () => {
        PerkoxSDK.closeListeners.forEach((listener) => {
          try {
            listener();
          } catch (e) {
            console.error("[Perkox SDK] Exception in onClose listener:", e);
          }
        });
      });
    }
  }

  /**
   * Cleans up all event listeners.
   */
  public static removeAllListeners(): void {
    PerkoxSDK.rewardListeners.clear();
    PerkoxSDK.closeListeners.clear();

    if (PerkoxSDK.rewardSubscription) {
      PerkoxSDK.rewardSubscription.remove();
      PerkoxSDK.rewardSubscription = null;
    }
    if (PerkoxSDK.closeSubscription) {
      PerkoxSDK.closeSubscription.remove();
      PerkoxSDK.closeSubscription = null;
    }
  }
}
