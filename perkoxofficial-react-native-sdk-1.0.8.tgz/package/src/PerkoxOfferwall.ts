import { PerkoxOfferwallConfig, PerkoxReward } from "./types";
import { PerkoxSDK } from "./PerkoxSDK";

export class OfferwallInstance {
  public appId: string;
  public sdkKey: string;
  public playerId: string;
  public beta: boolean = false;

  public onReward?: (reward: PerkoxReward) => void;
  public onClose?: () => void;

  private unsubReward: (() => void) | null = null;
  private unsubClose: (() => void) | null = null;

  constructor(appId: string, sdkKey: string, playerId: string) {
    this.appId = appId;
    this.sdkKey = sdkKey;
    this.playerId = playerId;
  }

  public getConfig(): PerkoxOfferwallConfig {
    return {
      appId: this.appId,
      sdkKey: this.sdkKey,
      playerId: this.playerId,
      beta: this.beta,
      onReward: this.onReward,
      onClose: this.onClose,
    };
  }

  /**
   * Triggers the Native Offerwall UI display using the native Android/iOS SDK bridge.
   */
  public async show(): Promise<boolean> {
    this.removeListeners();

    if (this.onReward) {
      this.unsubReward = PerkoxSDK.onReward((reward) => {
        if (this.onReward) {
          this.onReward(reward);
        }
      });
    }

    if (this.onClose) {
      this.unsubClose = PerkoxSDK.onClose(() => {
        if (this.onClose) {
          this.onClose();
        }
        this.removeListeners();
      });
    }

    return PerkoxSDK.showOfferwall({
      appId: this.appId,
      sdkKey: this.sdkKey,
      playerId: this.playerId,
      beta: this.beta,
    });
  }

  private removeListeners() {
    if (this.unsubReward) {
      this.unsubReward();
      this.unsubReward = null;
    }
    if (this.unsubClose) {
      this.unsubClose();
      this.unsubClose = null;
    }
  }
}

export class PerkoxOfferwall {
  /**
   * Initializes a new Perkox Offerwall instance (Hybrid Approach API).
   */
  public static init(appId: string, sdkKey: string, playerId: string, beta: boolean = false): OfferwallInstance {
    const instance = new OfferwallInstance(appId, sdkKey, playerId);
    instance.beta = beta;
    return instance;
  }

  /**
   * Creates a new Offerwall instance.
   */
  public static create(appId: string, sdkKey: string, playerId: string): OfferwallInstance {
    return new OfferwallInstance(appId, sdkKey, playerId);
  }

  /**
   * Directly shows the native offerwall via the bridge.
   */
  public static async showOfferwall(
    appId: string,
    sdkKey: string,
    playerId: string,
    beta: boolean = false
  ): Promise<boolean> {
    return PerkoxSDK.showOfferwall({
      appId,
      sdkKey,
      playerId,
      beta,
    });
  }
}
